function y=f_2(x)%定义第二题的函数%
y=4/(1+x.^2);
end