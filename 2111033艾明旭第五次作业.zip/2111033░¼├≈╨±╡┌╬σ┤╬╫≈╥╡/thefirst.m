%第一题%
f='cos(x)+2*sin(x)';
ezplot (f,[-2*pi,2*pi]);