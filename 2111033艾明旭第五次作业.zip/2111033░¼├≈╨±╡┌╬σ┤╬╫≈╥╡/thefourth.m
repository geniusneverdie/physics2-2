%第四题%
syms x;
disp(taylor(exp(x)));
disp(taylor(exp(x),'order',10));
disp(taylor(exp(x),x,2));
%taylor(exp(x))= x^5/120 + x^4/24 + x^3/6 + x^2/2 + x + 1%
%taylor(exp(x),'order',10)=x^9/362880 + x^8/40320 + x^7/5040 + x^6/720 + %
%                          x^5/120 + x^4/24 + x^3/6 + x^2/2 + x + 1      %
%taylor(exp(x),x,2)=exp(2) + exp(2)*(x - 2) + (exp(2)*(x - 2)^2)/2 +     %
%(exp(2)*(x - 2)^3)/6 + (exp(2)*(x - 2)^4)/24 + (exp(2)*(x - 2)^5)/120   %