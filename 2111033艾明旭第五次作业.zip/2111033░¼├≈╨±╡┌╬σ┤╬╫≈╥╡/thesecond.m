%第二题%
syms x y S1 S2 S3;%定义符号变量%
S1=8*x^3+27;
S2=(x-1)^3+(y+2)^2-(x+4)^2;
factor(S1);%还原S1的因式%
disp(S1);
expand(S2);%展开S2%
disp(S2);
collect(S2);%以x为独立变量合并S2的同类项%
disp(S2);
collect(S2,'y');%以y为独立变量合并S2的同类项%
disp(S2);
S3=(4*x^3+8*x^2+12*x)/(28*x^2-4*x*y);
simplify(S3);%化简S3式%
disp(S3);