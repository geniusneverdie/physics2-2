%第三题%
syms x P1 P2 P3 P4;
P1=1/(x+4);
P2=(3*x^2+5*x)/(x*(x+2));
P3=(x-2)^3+(x+1)^2;
P4=P1+P2+P3;
[num,den]=numden(P4);
disp(num);
disp(den);
%num=x^5 + x^4 - 8*x^3 + 40*x^2 + 88*x - 34%
%den=(x + 2)*(x + 4)%