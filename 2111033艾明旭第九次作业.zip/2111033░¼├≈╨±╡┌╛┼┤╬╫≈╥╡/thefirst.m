tspan=[0,0.1];%设定t的取值在0到0.1之间%
initial=[3 7 13];%给定y(1),y(2),y(3)的初始值%
[t,num_y]=ode45('eqns1',tspan,initial);%求解常微分方程%
subplot(3,1,1);%将y和y的一阶导数，二阶导数图像按三行一列形式排列，此为第一行%
plot(t,num_y(:,1)); %画出以t为自变量，y的第一列所有数值为因变量的图像%
title('原函数图像'), xlabel('t'), grid 
subplot(3,1,2);%将y和y的一阶导数，二阶导数图像按三行一列形式排列，此为第二行%
plot(t,num_y(:,2)); %画出以t为自变量，y的第二列所有数值为因变量的图像%
title('一阶导数图像'), xlabel('t'), grid
subplot(3,1,3);%将y和y的一阶导数，二阶导数图像按三行一列形式排列，此为第三行%
plot(t,num_y(:,3)); %画出以t为自变量，y的第二列所有数值为因变量的图像%
title('二阶导数图像'), xlabel('t'), grid