function dy=eqns2(t,y)
dy=zeros(3,1);%给定一个三行一列矩阵，用来存储经过降维之后的三个微分方程%
dy(1)=y(2);
dy(2)=y(3);
dy(3)=cos(y(1))+sin(y(2))-exp(y(3))+t^2;