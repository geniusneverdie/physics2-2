h=0.00001;%步长值h=0.00001%
t=0:h:0.1;%t的取值范围为0到0.1%
n=length(t);%求得t的个数%
num_y(1:3,1)=[3 7 13];%给定y(1),y(2),y(3)的初始值%
for k=1:n-1%龙格-库塔法的算法%
    k1=eqns2(t(k),num_y(:,k));%k1等于k时将t和num_y带入eqns2函数的值%
    k2=eqns2(t(k)+h/2,num_y(1:3,k)+k1*h/2);%k2等于k时将t+h/2和num_y+k1*h/2带入eqns2函数的值%
    k3=eqns2(t(k)+h/2,num_y(1:3,k)+k2*h/2);%k3等于k时将t+h/2和num_y+k2*h/2带入eqns2函数的值%
    k4=eqns2(t(k)+h,num_y(1:3,k)+k3*h);%k4等于k时将t+h和num_y+k3*h带入eqns2函数的值%
    num_y(1:3,k+1)=num_y(1:3,k)+h*(k1+2*k2+2*k3+k4)/6;%k+1时的num_y等于k时的num_y+k时的k1,k2,k3,k4组成的关系式%
end
subplot(3,1,1);%将y和y的一阶导数，二阶导数图像按三行一列形式排列，此为第一行%
plot(t,num_y(1,:)); %画出以t为自变量，y的第一行所有数值为因变量的图像%
title('原函数图像'), xlabel('t'), grid 
subplot(3,1,2);%将y和y的一阶导数，二阶导数图像按三行一列形式排列，此为第二行%
plot(t,num_y(2,:)); %画出以t为自变量，y的第二行所有数值为因变量的图像%
title('一阶导数图像'), xlabel('t'), grid
subplot(3,1,3);%将y和y的一阶导数，二阶导数图像按三行一列形式排列，此为第三行%
plot(t,num_y(3,:)); %画出以t为自变量，y的第三行所有数值为因变量的图像%
title('二阶导数图像'), xlabel('t'), grid