%%
%第四题第一问%
S=dsolve('Dx=y,Dy=-x');%求解微分方程组%
disp(S.x);%输出x的表达式%
disp(S.y);%输出y的表达式%
%x=C1*cos(t) + C2*sin(t)%
%y=C2*cos(t) - C1*sin(t)%
%%
%第四题第二问%
S=dsolve('Dy+y=a*sin(x)','x');%求解微分方程%
disp(S);%输出结果%
%y=C1*exp(-x) - (a*(cos(x) - sin(x)))/2%