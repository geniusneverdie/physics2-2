function y=f_1(x)
y=4./(1+x.^2);
end