function y=f_2(x)
y=exp(x);
end