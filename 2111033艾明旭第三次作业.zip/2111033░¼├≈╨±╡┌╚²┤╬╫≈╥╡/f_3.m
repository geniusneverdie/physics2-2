function y=f_3(x)
y=2*exp(-x).*cos(2*pi.*x)-0.5;
end