function y=f_4_2(x)
y=2.*tan(x)-x;
end