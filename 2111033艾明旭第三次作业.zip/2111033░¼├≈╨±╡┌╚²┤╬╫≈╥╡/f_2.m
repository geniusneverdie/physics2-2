function y=f_2(x)
y=x.^3-x-1;
end