function y=f_4_1(x)
y=x.^5-4*x-2;
end