function y=f_4_3(x)
y=2.*sin(x)-x;
end