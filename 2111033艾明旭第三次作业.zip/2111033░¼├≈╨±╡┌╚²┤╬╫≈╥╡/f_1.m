function y=f_1(x)%定义f_1(x)函数%
y=x.^3-2*x-5;
end